<?php
// ================================================================
// includes/bootstrap.php — Fichier central, chargé par toutes les pages
// ================================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ── Connexion BDD ────────────────────────────────────────────────
$host   = 'localhost';
$dbName = 'danslebueno';
$dbUser = 'root';
$dbPass = 'root'; // ← adapte si besoin

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbName;charset=utf8mb4",
        $dbUser, $dbPass,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    http_response_code(503);
    die('<h1>Erreur de connexion BDD</h1><p>' . htmlspecialchars($e->getMessage()) . '</p>');
}

// ── Constantes upload ────────────────────────────────────────────
// UPLOAD_DIR = chemin absolu vers le dossier uploads/ à la racine du projet
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
// UPLOAD_URL = URL relative utilisée dans les balises <img src="...">
define('UPLOAD_URL', 'uploads/');
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024); // 5 Mo

// ── Helpers HTML ─────────────────────────────────────────────────
function h(mixed $v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $url): never {
    header('Location: ' . $url);
    exit;
}

// ── Auth ─────────────────────────────────────────────────────────
function is_logged_in(): bool {
    return !empty($_SESSION['user_id']);
}

function is_admin(): bool {
    return !empty($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function require_login(): void {
    if (!is_logged_in()) {
        set_flash('flash_error', 'Vous devez être connecté.');
        redirect('auth.php?mode=connexion');
    }
}

function require_admin(): void {
    require_login();
    if (!is_admin()) {
        set_flash('flash_error', 'Accès réservé aux administrateurs.');
        redirect('index.php');
    }
}

function current_user(PDO $pdo): array {
    if (!is_logged_in()) return [];
    $s = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
    $s->execute([(int)$_SESSION['user_id']]);
    return $s->fetch() ?: [];
}

// ── CSRF ─────────────────────────────────────────────────────────
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_or_fail(string $back): void {
    if (!hash_equals((string)csrf_token(), (string)($_POST['csrf_token'] ?? ''))) {
        set_flash('flash_error', 'Token invalide, réessayez.');
        redirect($back);
    }
}

// ── Flash messages ───────────────────────────────────────────────
function flash(string $key): string {
    $v = $_SESSION[$key] ?? '';
    unset($_SESSION[$key]);
    return (string)$v;
}

function set_flash(string $key, string $val): void {
    $_SESSION[$key] = $val;
}

function pull_array(string $key): array {
    $v = $_SESSION[$key] ?? [];
    unset($_SESSION[$key]);
    return is_array($v) ? $v : [];
}

function old(array $arr, string $field): string {
    return (string)($arr[$field] ?? '');
}

// ── Images ───────────────────────────────────────────────────────
function image_url(?string $filename): string {
    return empty($filename) ? '' : UPLOAD_URL . $filename;
}

/**
 * Gère l'upload d'une image de façon sécurisée.
 * Retourne le nouveau nom de fichier, ou $old si rien n'est uploadé.
 */
function handle_uploaded_image(array $file, ?string $old = null): ?string {
    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return $old;
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Erreur upload (code ' . $file['error'] . ').');
    }
    if ($file['size'] > MAX_UPLOAD_SIZE) {
        throw new RuntimeException('Image trop lourde (max 5 Mo).');
    }
    $allowed = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_GIF => 'gif', IMAGETYPE_WEBP => 'webp'];
    $type = @exif_imagetype($file['tmp_name']);
    if ($type === false || !isset($allowed[$type])) {
        throw new RuntimeException('Format non autorisé (JPG, PNG, WEBP, GIF).');
    }
    if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);
    $name = uniqid('img_', true) . '.' . $allowed[$type];
    if (!move_uploaded_file($file['tmp_name'], UPLOAD_DIR . $name)) {
        throw new RuntimeException('Impossible de sauvegarder l\'image.');
    }
    delete_image_file($old);
    return $name;
}

function delete_image_file(?string $filename): void {
    if (empty($filename)) return;
    $path = UPLOAD_DIR . basename($filename);
    if (is_file($path)) @unlink($path);
}

// ── Formatage annonces ───────────────────────────────────────────
function format_price(mixed $prix): string {
    return number_format((float)$prix, 0, ',', ' ') . ' €';
}

// IMPORTANT : les états en BDD sont 'neuf', 'bon', 'correct' (minuscules)
function state_label(string $etat): string {
    return match ($etat) {
        'neuf'    => 'Neuf',
        'bon'     => 'Bon état',
        'correct' => 'État correct',
        default   => ucfirst($etat),
    };
}

// ── Compteurs navbar ─────────────────────────────────────────────
function count_unread(PDO $pdo): int {
    if (!is_logged_in()) return 0;
    $s = $pdo->prepare('SELECT COUNT(*) FROM messages WHERE receiver_id = ? AND is_read = 0');
    $s->execute([(int)$_SESSION['user_id']]);
    return (int)$s->fetchColumn();
}

function count_favorites(PDO $pdo): int {
    if (!is_logged_in()) return 0;
    $s = $pdo->prepare('SELECT COUNT(*) FROM favoris WHERE user_id = ?');
    $s->execute([(int)$_SESSION['user_id']]);
    return (int)$s->fetchColumn();
}

// ── Navbar ───────────────────────────────────────────────────────
function render_navbar(string $q = ''): void {
    global $pdo;
    $loggedIn  = is_logged_in();
    $adminRole = is_admin();
    $pseudo    = h($_SESSION['pseudo'] ?? '');
    $qh        = h($q);
    $nbMsg     = $loggedIn ? count_unread($pdo)    : 0;
    $nbFav     = $loggedIn ? count_favorites($pdo) : 0;

    $badgeMsg = $nbMsg > 0
        ? '<span class="position-absolute badge rounded-pill bg-danger" style="top:-5px;right:-8px;font-size:.6rem;min-width:16px;padding:2px 4px;">' . $nbMsg . '</span>'
        : '';
    $badgeFav = $nbFav > 0
        ? '<span class="position-absolute badge rounded-pill" style="top:-5px;right:-8px;font-size:.6rem;min-width:16px;padding:2px 4px;background:var(--color-sky);">' . $nbFav . '</span>'
        : '';

    echo '
<nav class="navbar navbar-expand-lg navbar-danslebueno fixed-top">
  <div class="container-xl d-flex align-items-center gap-3">

    <a href="index.php" class="navbar-brand me-lg-3 flex-shrink-0">
      <span class="logo-text">
        <span class="logo-dans">dans</span><span class="logo-le">le</span><span class="logo-bueno">bueno</span>
      </span>
    </a>

    <form action="index.php" method="GET" class="search-bar-wrapper d-none d-md-flex flex-grow-1">
      <div class="input-group w-100">
        <input type="search" class="form-control" placeholder="Rechercher une annonce…"
               name="q" value="' . $qh . '" autocomplete="off">
        <button class="btn-search" type="submit"><i class="bi bi-search"></i></button>
      </div>
    </form>

    <button class="navbar-toggler border-0 ms-auto" type="button"
      data-bs-toggle="collapse" data-bs-target="#navMain">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse flex-grow-0" id="navMain">
      <form action="index.php" method="GET" class="search-bar-wrapper d-md-none my-2 w-100">
        <div class="input-group w-100">
          <input type="search" class="form-control" placeholder="Rechercher…" name="q" value="' . $qh . '">
          <button class="btn-search" type="submit"><i class="bi bi-search"></i></button>
        </div>
      </form>

      <div class="d-flex align-items-center gap-2 gap-lg-3 mt-2 mt-lg-0">
        <a href="deposer-annonce.php" class="btn btn-deposer flex-shrink-0">
          <i class="bi bi-plus-lg me-1"></i>Déposer
        </a>';

    if ($loggedIn) {
        $adminItem = $adminRole
            ? '<li><hr class="dropdown-divider"></li>
               <li><a class="dropdown-item text-warning fw-bold" href="admin.php">
                 <i class="bi bi-shield-lock me-2"></i>Administration</a></li>'
            : '';

        echo '
        <a href="mes-favoris.php" class="nav-icon-link position-relative">
          <i class="bi bi-heart"></i>' . $badgeFav . '
          <span>Favoris</span>
        </a>

        <a href="messagerie.php" class="nav-icon-link position-relative">
          <i class="bi bi-chat-dots"></i>' . $badgeMsg . '
          <span>Messages</span>
        </a>

        <div class="dropdown">
          <a href="#" class="nav-icon-link" data-bs-toggle="dropdown">
            <i class="bi bi-person-circle"></i>
            <span>' . $pseudo . '</span>
          </a>
          <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 rounded-3 mt-1">
            <li><a class="dropdown-item" href="profil.php">
              <i class="bi bi-person me-2 text-muted"></i>Mon profil</a></li>
            <li><a class="dropdown-item" href="mes-annonces.php">
              <i class="bi bi-tag me-2 text-muted"></i>Mes annonces</a></li>
            <li><a class="dropdown-item" href="mes-favoris.php">
              <i class="bi bi-heart me-2 text-muted"></i>Mes favoris</a></li>
            ' . $adminItem . '
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="logout.php">
              <i class="bi bi-box-arrow-right me-2"></i>Déconnexion</a></li>
          </ul>
        </div>';
    } else {
        echo '
        <a href="auth.php?mode=connexion" class="nav-icon-link">
          <i class="bi bi-person"></i><span>Connexion</span>
        </a>';
    }

    echo '
      </div>
    </div>
  </div>
</nav>';
}
