<?php
// ================================================================
// supprimer-annonce.php
// ================================================================
require_once __DIR__ . '/includes/bootstrap.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('mes-annonces.php');
verify_csrf_or_fail('mes-annonces.php');

$id     = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$userId = (int)$_SESSION['user_id'];

if ($id <= 0) { set_flash('flash_error', 'Annonce invalide.'); redirect('mes-annonces.php'); }

$stmt = $pdo->prepare('SELECT id, user_id, image FROM annonces WHERE id = ? LIMIT 1');
$stmt->execute([$id]);
$annonce = $stmt->fetch();

if (!$annonce) { set_flash('flash_error', 'Annonce introuvable.'); redirect('mes-annonces.php'); }

if ((int)$annonce['user_id'] !== $userId && !is_admin()) {
    set_flash('flash_error', 'Action non autorisée.');
    redirect('mes-annonces.php');
}

delete_image_file($annonce['image']);
$pdo->prepare('DELETE FROM annonces WHERE id = ?')->execute([$id]);

set_flash('flash_success', 'Annonce supprimée.');
redirect('mes-annonces.php');
