<?php
// =============================================================
// mes-annonces.php
// =============================================================
require_once __DIR__ . '/includes/bootstrap.php';
require_login();

$userId = (int)$_SESSION['user_id'];

$stmt = $pdo->prepare("
    SELECT id, titre, prix, etat, description, image, created_at
    FROM annonces
    WHERE user_id = ?
    ORDER BY created_at DESC, id DESC
");
$stmt->execute([$userId]);
$annonces = $stmt->fetchAll();

$flashSuccess = flash('flash_success');
$flashError   = flash('flash_error');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Mes annonces – DansLeBueno</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@700;800;900&family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="style.css" />
</head>
<body>
<?php render_navbar(); ?>

<section class="page-hero">
  <div class="container-xl">
    <nav aria-label="breadcrumb" class="mb-1">
      <ol class="breadcrumb mb-0" style="font-size:.82rem;">
        <li class="breadcrumb-item"><a href="index.php">Accueil</a></li>
        <li class="breadcrumb-item active">Mes annonces</li>
      </ol>
    </nav>
    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
      <h1 class="mb-0">Mes annonces</h1>
      <a href="deposer-annonce.php" class="btn btn-deposer">
        <i class="bi bi-plus-lg me-1"></i>Nouvelle annonce
      </a>
    </div>
  </div>
</section>

<div class="container-xl pb-5">

  <?php if ($flashSuccess): ?>
    <div class="alert alert-success"><?= h($flashSuccess) ?></div>
  <?php endif; ?>
  <?php if ($flashError): ?>
    <div class="alert alert-danger"><?= h($flashError) ?></div>
  <?php endif; ?>

  <?php if (empty($annonces)): ?>
    <div class="empty-state">
      <i class="bi bi-tag"></i>
      <h5 class="mt-2">Vous n'avez publié aucune annonce</h5>
      <p>Déposez votre première annonce en quelques clics.</p>
      <a href="deposer-annonce.php" class="btn btn-primary-orange mt-2 rounded-pill px-4">
        Déposer une annonce
      </a>
    </div>

  <?php else: ?>
    <div class="d-flex flex-column gap-3">
      <?php foreach ($annonces as $a): ?>
        <div class="bg-white rounded-3 shadow-sm p-3 d-flex align-items-center gap-3">

          <!-- Image ou placeholder -->
          <?php if (!empty($a['image'])): ?>
            <img
              src="<?= h(image_url($a['image'])) ?>"
              alt="<?= h($a['titre']) ?>"
              style="width:88px;height:70px;object-fit:cover;border-radius:var(--radius-sm);flex-shrink:0;"
            />
          <?php else: ?>
            <div style="width:88px;height:70px;border-radius:var(--radius-sm);
              background:var(--color-neutral-200);display:flex;align-items:center;
              justify-content:center;color:var(--color-neutral-500);flex-shrink:0;">
              <i class="bi bi-image fs-4"></i>
            </div>
          <?php endif; ?>

          <!-- Infos -->
          <div class="flex-grow-1 min-w-0">
            <div class="fw-bold text-truncate" style="font-size:.95rem;">
              <?= h($a['titre']) ?>
            </div>
            <div class="d-flex align-items-center gap-2 mt-1 flex-wrap">
              <span class="annonce-price" style="font-size:1rem;"><?= h(format_price($a['prix'])) ?></span>
              <span class="badge-etat <?= h($a['etat']) ?>"><?= h(state_label($a['etat'])) ?></span>
              <small class="text-muted">
                Publiée le <?= date('d/m/Y', strtotime($a['created_at'])) ?>
              </small>
            </div>
          </div>

          <!-- Actions -->
          <div class="d-flex gap-2 flex-shrink-0 flex-wrap justify-content-end">
            <a href="detail-annonce.php?id=<?= (int)$a['id'] ?>"
              class="btn btn-outline-secondary btn-sm rounded-pill" title="Voir">
              <i class="bi bi-eye"></i>
            </a>
            <a href="deposer-annonce.php?id=<?= (int)$a['id'] ?>"
              class="btn btn-outline-secondary btn-sm rounded-pill" title="Modifier">
              <i class="bi bi-pencil"></i>
            </a>
            <form action="supprimer-annonce.php" method="POST"
              onsubmit="return confirm('Supprimer définitivement cette annonce ?');">
              <input type="hidden" name="id"          value="<?= (int)$a['id'] ?>">
              <input type="hidden" name="csrf_token"  value="<?= h(csrf_token()) ?>">
              <button type="submit" class="btn btn-outline-danger btn-sm rounded-pill" title="Supprimer">
                <i class="bi bi-trash"></i>
              </button>
            </form>
          </div>

        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

</div>

<footer class="site-footer">
  <div class="container-xl">
    <div class="footer-divider mt-0"></div>
    <p class="text-center mb-0" style="font-size:.8rem;">&copy; <?= date('Y') ?> DansLeBueno – Projet étudiant.</p>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
