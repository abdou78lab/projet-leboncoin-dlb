<?php
// ================================================================
// envoyer-message.php
// ================================================================
require_once __DIR__ . '/includes/bootstrap.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('messagerie.php');
verify_csrf_or_fail('messagerie.php');

$fromId     = (int)$_SESSION['user_id'];
$annonceId  = isset($_POST['annonce_id'])  ? (int)$_POST['annonce_id']  : 0;
$toId       = isset($_POST['to_user_id'])  ? (int)$_POST['to_user_id']  : 0;
$contenu    = trim((string)($_POST['contenu'] ?? ''));
$redirectTo = trim((string)($_POST['redirect_to'] ?? ''));

if (!preg_match('/^messagerie\.php/', $redirectTo)) {
    $redirectTo = 'messagerie.php';
}
if ($annonceId > 0 && $toId > 0) {
    $redirectTo = "messagerie.php?annonce_id=$annonceId&user_id=$toId";
}

if ($annonceId <= 0 || $toId <= 0)   { set_flash('flash_error', 'Paramètres invalides.'); redirect($redirectTo); }
if ($fromId === $toId)                 { set_flash('flash_error', 'Vous ne pouvez pas vous envoyer un message.'); redirect($redirectTo); }
if ($contenu === '')                   { set_flash('flash_error', 'Le message est vide.'); redirect($redirectTo); }
if (mb_strlen($contenu) > 1000)       { set_flash('flash_error', 'Message trop long (max 1000 caractères).'); redirect($redirectTo); }

// Vérifier annonce et destinataire
$s = $pdo->prepare('SELECT id FROM annonces WHERE id = ? LIMIT 1');
$s->execute([$annonceId]);
if (!$s->fetch()) { set_flash('flash_error', 'Annonce introuvable.'); redirect('messagerie.php'); }

$s = $pdo->prepare('SELECT id FROM users WHERE id = ? AND actif = 1 LIMIT 1');
$s->execute([$toId]);
if (!$s->fetch()) { set_flash('flash_error', 'Destinataire introuvable.'); redirect($redirectTo); }

$s = $pdo->prepare('INSERT INTO messages (annonce_id, sender_id, receiver_id, contenu, is_read, created_at) VALUES (?, ?, ?, ?, 0, NOW())');
$s->execute([$annonceId, $fromId, $toId, $contenu]);

set_flash('flash_success', 'Message envoyé.');
redirect($redirectTo);
