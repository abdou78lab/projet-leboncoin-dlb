<?php
// =============================================================
// diagnostic.php — À SUPPRIMER APRÈS UTILISATION
// Dépose ce fichier à la RACINE de ton projet et ouvre-le
// dans ton navigateur : http://localhost/danslebueno/diagnostic.php
// =============================================================

// Connexion BDD — adapte si besoin
$host   = 'localhost';
$dbName = 'danslebueno';
$dbUser = 'root';
$dbPass = ''; // ← mets ton mot de passe ici si tu en as un

echo '<style>
  body { font-family: monospace; padding: 20px; background: #f5f5f5; }
  h2   { margin-top: 30px; }
  .ok  { color: green;  font-weight: bold; }
  .err { color: red;    font-weight: bold; }
  .warn{ color: orange; font-weight: bold; }
  table{ border-collapse: collapse; width: 100%; margin-top: 10px; }
  td,th{ border: 1px solid #ccc; padding: 6px 10px; font-size: 13px; }
  th   { background: #ddd; }
  pre  { background:#222; color:#0f0; padding:10px; border-radius:4px; }
</style>';

echo '<h1>🔍 Diagnostic photos – DansLeBueno</h1>';

// ── 1. STRUCTURE DES DOSSIERS ────────────────────────────────
echo '<h2>1. Structure des dossiers</h2>';

$root        = __DIR__;                  // racine du projet
$uploadsDir  = $root . '/uploads/';
$includesDir = $root . '/includes/';

echo '<table><tr><th>Chemin</th><th>Existe ?</th><th>Lisible ?</th><th>Écrivable ?</th></tr>';

$dirs = [
    'Racine projet'   => $root,
    'uploads/'        => $uploadsDir,
    'includes/'       => $includesDir,
];

foreach ($dirs as $label => $path) {
    $exists   = file_exists($path);
    $readable = $exists && is_readable($path);
    $writable = $exists && is_writable($path);
    echo "<tr>
      <td>$label<br><small style='color:#888;'>$path</small></td>
      <td class='" . ($exists   ? 'ok'  : 'err') . "'>" . ($exists   ? '✅ OUI' : '❌ NON') . "</td>
      <td class='" . ($readable ? 'ok'  : 'err') . "'>" . ($readable ? '✅ OUI' : '❌ NON') . "</td>
      <td class='" . ($writable ? 'ok'  : 'warn') . "'>" . ($writable ? '✅ OUI' : '⚠️ NON') . "</td>
    </tr>";
}
echo '</table>';

// ── 2. FICHIERS DANS uploads/ ────────────────────────────────
echo '<h2>2. Fichiers présents dans uploads/</h2>';

if (!is_dir($uploadsDir)) {
    echo '<p class="err">❌ Le dossier uploads/ n\'existe pas à la racine du projet !</p>';
    echo '<p>Crée-le manuellement : <pre>mkdir ' . $uploadsDir . '</pre></p>';
} else {
    $files = array_diff(scandir($uploadsDir), ['.', '..']);
    if (empty($files)) {
        echo '<p class="warn">⚠️ Le dossier uploads/ est vide. Aucune image uploadée.</p>';
    } else {
        echo '<table><tr><th>Fichier</th><th>Taille</th><th>URL publique</th><th>Prévisualisation</th></tr>';
        foreach ($files as $f) {
            $fullPath = $uploadsDir . $f;
            $size     = round(filesize($fullPath) / 1024, 1) . ' Ko';
            $url      = 'uploads/' . $f;
            $isImage  = preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $f);
            $preview  = $isImage ? "<img src='$url' style='max-height:60px;max-width:120px;object-fit:cover;border-radius:4px;'>" : '(non-image)';
            echo "<tr>
              <td>$f</td>
              <td>$size</td>
              <td><a href='$url' target='_blank'>$url</a></td>
              <td>$preview</td>
            </tr>";
        }
        echo '</table>';
    }
}

// ── 3. CONNEXION BDD ─────────────────────────────────────────
echo '<h2>3. Connexion base de données</h2>';

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbName;charset=utf8mb4",
        $dbUser, $dbPass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
    echo '<p class="ok">✅ Connexion à la base de données réussie.</p>';
} catch (PDOException $e) {
    echo '<p class="err">❌ Impossible de se connecter : ' . htmlspecialchars($e->getMessage()) . '</p>';
    echo '<p>Vérifie les identifiants dans diagnostic.php (lignes 10-13).</p>';
    die();
}

// ── 4. TABLE annonces — champ image ──────────────────────────
echo '<h2>4. Valeur du champ <code>image</code> dans la table annonces</h2>';

$stmt = $pdo->query('SELECT id, titre, image FROM annonces ORDER BY id DESC LIMIT 20');
$annonces = $stmt->fetchAll();

if (empty($annonces)) {
    echo '<p class="warn">⚠️ Aucune annonce dans la base de données.</p>';
} else {
    echo '<table><tr><th>ID</th><th>Titre</th><th>Valeur image en BDD</th><th>Fichier existe ?</th><th>URL générée</th><th>Aperçu</th></tr>';
    foreach ($annonces as $a) {
        $imgVal  = $a['image'];
        $isEmpty = ($imgVal === null || $imgVal === '');

        if ($isEmpty) {
            echo "<tr>
              <td>{$a['id']}</td>
              <td>" . htmlspecialchars($a['titre']) . "</td>
              <td class='warn'>NULL / vide</td>
              <td>—</td><td>—</td><td>—</td>
            </tr>";
            continue;
        }

        // Est-ce que le fichier existe physiquement ?
        $filePath  = $uploadsDir . $imgVal;
        $fileExists = file_exists($filePath);

        // URL publique
        $publicUrl = 'uploads/' . $imgVal;

        // Prévisualisation
        $preview = $fileExists
            ? "<img src='$publicUrl' style='max-height:60px;max-width:120px;object-fit:cover;border-radius:4px;'>"
            : '<span class="err">Fichier introuvable !</span>';

        echo "<tr>
          <td>{$a['id']}</td>
          <td>" . htmlspecialchars($a['titre']) . "</td>
          <td><code>" . htmlspecialchars($imgVal) . "</code></td>
          <td class='" . ($fileExists ? 'ok' : 'err') . "'>" . ($fileExists ? '✅ OUI' : '❌ NON') . "</td>
          <td><a href='$publicUrl' target='_blank'>$publicUrl</a></td>
          <td>$preview</td>
        </tr>";
    }
    echo '</table>';
}

// ── 5. TEST UPLOAD EN DIRECT ─────────────────────────────────
echo '<h2>5. Test upload d\'une image</h2>';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['test_image'])) {
    $f = $_FILES['test_image'];
    if ($f['error'] !== UPLOAD_ERR_OK) {
        echo '<p class="err">❌ Erreur upload : code ' . $f['error'] . '</p>';
    } else {
        $ext     = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
        $newName = 'test_' . time() . '.' . $ext;
        $dest    = $uploadsDir . $newName;

        if (!is_dir($uploadsDir)) {
            mkdir($uploadsDir, 0755, true);
        }

        if (move_uploaded_file($f['tmp_name'], $dest)) {
            echo "<p class='ok'>✅ Upload réussi ! Fichier : <code>uploads/$newName</code></p>";
            echo "<img src='uploads/$newName' style='max-height:150px;border-radius:8px;'>";
            echo "<p>Si tu vois l'image ci-dessus, les uploads fonctionnent correctement.</p>";
        } else {
            echo '<p class="err">❌ move_uploaded_file() a échoué. Vérifie les permissions du dossier uploads/.</p>';
        }
    }
}

echo '
<form method="POST" enctype="multipart/form-data" style="margin-top:10px;padding:15px;background:#fff;border-radius:8px;display:inline-block;">
  <label style="font-weight:bold;">Tester l\'upload d\'une image :</label><br><br>
  <input type="file" name="test_image" accept="image/*" required style="margin-bottom:10px;display:block;">
  <button type="submit" style="background:#FF6B35;color:#fff;border:none;padding:8px 20px;border-radius:20px;cursor:pointer;font-weight:bold;">
    Uploader le fichier test
  </button>
</form>';

// ── 6. RÉSUMÉ ET SOLUTION ────────────────────────────────────
echo '<h2>6. Ce qu\'il faut vérifier</h2>';
echo '<div style="background:#fff;padding:15px;border-radius:8px;border-left:4px solid #FF6B35;">
<ol style="line-height:2;">
  <li>Le dossier <code>uploads/</code> doit exister <strong>à la racine de ton projet</strong> (même niveau que index.php)</li>
  <li>La colonne <code>image</code> en BDD doit contenir <strong>seulement le nom du fichier</strong> (ex: <code>img_abc123.jpg</code>), pas le chemin complet</li>
  <li>Le fichier doit physiquement être présent dans <code>uploads/</code></li>
  <li>Sur WAMP/XAMPP, le dossier uploads/ doit avoir les droits d\'écriture</li>
</ol>
</div>';

echo '<hr><p style="color:#999;font-size:12px;">⚠️ Supprime ce fichier diagnostic.php dès que tu as résolu le problème.</p>';
