<?php
// ================================================================
// toggle-favori.php
// ================================================================
require_once __DIR__ . '/includes/bootstrap.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('index.php');
verify_csrf_or_fail('index.php');

$userId    = (int)$_SESSION['user_id'];
$annonceId = isset($_POST['annonce_id']) ? (int)$_POST['annonce_id'] : 0;
$redirectTo = trim((string)($_POST['redirect_to'] ?? ''));

// Sécurité open redirect
if (!preg_match('/^[a-z0-9_\-]+\.php(\?.*)?$/i', $redirectTo)) {
    $redirectTo = 'index.php';
}

if ($annonceId <= 0) {
    set_flash('flash_error', 'Annonce invalide.');
    redirect($redirectTo);
}

$stmt = $pdo->prepare('SELECT id, user_id FROM annonces WHERE id = ? LIMIT 1');
$stmt->execute([$annonceId]);
$annonce = $stmt->fetch();

if (!$annonce) {
    set_flash('flash_error', 'Annonce introuvable.');
    redirect($redirectTo);
}

if ((int)$annonce['user_id'] === $userId) {
    set_flash('flash_error', 'Vous ne pouvez pas mettre votre propre annonce en favori.');
    redirect($redirectTo ?: 'detail-annonce.php?id=' . $annonceId);
}

$stmt = $pdo->prepare('SELECT 1 FROM favoris WHERE user_id = ? AND annonce_id = ? LIMIT 1');
$stmt->execute([$userId, $annonceId]);
$exists = (bool)$stmt->fetchColumn();

if ($exists) {
    $pdo->prepare('DELETE FROM favoris WHERE user_id = ? AND annonce_id = ?')->execute([$userId, $annonceId]);
    set_flash('flash_success', 'Retiré de vos favoris.');
} else {
    $pdo->prepare('INSERT INTO favoris (user_id, annonce_id) VALUES (?, ?)')->execute([$userId, $annonceId]);
    set_flash('flash_success', 'Ajouté à vos favoris !');
}

redirect($redirectTo ?: 'detail-annonce.php?id=' . $annonceId);
