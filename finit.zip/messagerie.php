<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();

$userId = (int)$_SESSION['user_id'];

// ── 1. Charger les conversations ─────────────────────────────────
// On évite le CASE dans le GROUP BY (incompatible MySQL strict mode).
// On passe par une sous-requête avec UNION pour normaliser sender/receiver.
$sql = "
    SELECT
        annonce_id,
        other_user_id,
        MAX(last_at)   AS last_at,
        SUM(non_lu)    AS nb_non_lus
    FROM (
        SELECT
            annonce_id,
            receiver_id AS other_user_id,
            created_at  AS last_at,
            0           AS non_lu
        FROM messages
        WHERE sender_id = :uid1

        UNION ALL

        SELECT
            annonce_id,
            sender_id   AS other_user_id,
            created_at  AS last_at,
            CASE WHEN is_read = 0 THEN 1 ELSE 0 END AS non_lu
        FROM messages
        WHERE receiver_id = :uid2
    ) AS fils
    GROUP BY annonce_id, other_user_id
    ORDER BY last_at DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute(['uid1' => $userId, 'uid2' => $userId]);
$rows = $stmt->fetchAll();

// Enrichir avec pseudo interlocuteur + infos annonce
$threads = [];
foreach ($rows as $row) {
    // Pseudo interlocuteur
    $su = $pdo->prepare('SELECT id, pseudo FROM users WHERE id = ? LIMIT 1');
    $su->execute([(int)$row['other_user_id']]);
    $otherUser = $su->fetch();

    // Infos annonce
    $sa = $pdo->prepare('SELECT id, titre, image, prix FROM annonces WHERE id = ? LIMIT 1');
    $sa->execute([(int)$row['annonce_id']]);
    $annInfo = $sa->fetch();

    if (!$annInfo) continue; // annonce supprimée → ignorer le fil

    $threads[] = [
        'annonce_id'    => (int)$row['annonce_id'],
        'annonce_titre' => $annInfo['titre'],
        'annonce_image' => $annInfo['image'],
        'annonce_prix'  => $annInfo['prix'],
        'other_user_id' => (int)$row['other_user_id'],
        'other_pseudo'  => $otherUser['pseudo'] ?? 'Utilisateur',
        'last_at'       => $row['last_at'],
        'nb_non_lus'    => (int)$row['nb_non_lus'],
    ];
}

// ── 2. Fil actif ─────────────────────────────────────────────────
$selAnnonce = isset($_GET['annonce_id']) ? (int)$_GET['annonce_id'] : 0;
$selUser    = isset($_GET['user_id'])    ? (int)$_GET['user_id']    : 0;

// Ouvrir le premier fil si aucun sélectionné
if ($selAnnonce === 0 && !empty($threads)) {
    $selAnnonce = $threads[0]['annonce_id'];
    $selUser    = $threads[0]['other_user_id'];
}

// Fil actif courant
$activeThread = null;
foreach ($threads as $t) {
    if ($t['annonce_id'] === $selAnnonce && $t['other_user_id'] === $selUser) {
        $activeThread = $t;
        break;
    }
}

// ── 3. Messages du fil actif ─────────────────────────────────────
$messages = [];
if ($selAnnonce > 0 && $selUser > 0) {
    // Marquer comme lus
    $mr = $pdo->prepare(
        'UPDATE messages SET is_read = 1
         WHERE annonce_id = ? AND sender_id = ? AND receiver_id = ? AND is_read = 0'
    );
    $mr->execute([$selAnnonce, $selUser, $userId]);

    // Charger messages
    $ms = $pdo->prepare("
        SELECT m.*, u.pseudo AS from_pseudo
        FROM messages m
        JOIN users u ON u.id = m.sender_id
        WHERE m.annonce_id = ?
          AND (
            (m.sender_id = ? AND m.receiver_id = ?)
            OR
            (m.sender_id = ? AND m.receiver_id = ?)
          )
        ORDER BY m.created_at ASC, m.id ASC
    ");
    $ms->execute([$selAnnonce, $userId, $selUser, $selUser, $userId]);
    $messages = $ms->fetchAll();
}

// ── 4. Infos annonce active ──────────────────────────────────────
$annonceActive = null;
if ($selAnnonce > 0) {
    $sa = $pdo->prepare('SELECT id, titre, prix, image FROM annonces WHERE id = ? LIMIT 1');
    $sa->execute([$selAnnonce]);
    $annonceActive = $sa->fetch();
}

$flashSuccess = flash('flash_success');
$flashError   = flash('flash_error');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Messagerie – DansLeBueno</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@700;800;900&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="style.css">
</head>
<body>
<?php render_navbar(); ?>

<div class="messaging-layout">

  <!-- ── PANNEAU GAUCHE : conversations ──────────────────────── -->
  <div class="conv-list-panel">
    <div class="conv-list-header">
      <i class="bi bi-chat-left-dots me-2"></i>Discussions
    </div>
    <div class="conv-list-scroll">

      <?php if (empty($threads)): ?>
        <div class="empty-state py-5">
          <i class="bi bi-chat-dots"></i>
          <p class="mt-2">Aucune discussion pour l'instant.</p>
        </div>
      <?php else: foreach ($threads as $t):
          $isActive = ($t['annonce_id'] === $selAnnonce && $t['other_user_id'] === $selUser);
          $init     = strtoupper(substr($t['other_pseudo'], 0, 1));

          // Date formatée
          $ts    = strtotime($t['last_at']);
          $today = strtotime('today');
          if ($ts >= $today)              $dateLabel = date('H:i', $ts);
          elseif ($ts >= $today - 86400)  $dateLabel = 'Hier';
          else                            $dateLabel = date('d/m', $ts);
      ?>
        <a href="messagerie.php?annonce_id=<?= (int)$t['annonce_id'] ?>&user_id=<?= (int)$t['other_user_id'] ?>"
           class="conv-item text-decoration-none <?= $isActive ? 'active' : '' ?>">

          <div class="conv-avatar"><?= h($init) ?></div>

          <div class="conv-meta">
            <div class="conv-name"><?= h($t['other_pseudo']) ?></div>
            <div class="conv-last-msg"><?= h($t['annonce_titre']) ?></div>
          </div>

          <div class="d-flex flex-column align-items-end gap-1 flex-shrink-0">
            <?php if (!empty($t['annonce_image'])): ?>
              <img src="<?= h(image_url($t['annonce_image'])) ?>"
                   class="conv-annonce-thumb" alt="">
            <?php else: ?>
              <div class="conv-annonce-thumb d-flex align-items-center justify-content-center"
                   style="background:var(--color-neutral-200);">
                <i class="bi bi-image" style="font-size:.75rem;color:var(--color-neutral-500);"></i>
              </div>
            <?php endif; ?>
            <small class="text-muted" style="font-size:.68rem;"><?= h($dateLabel) ?></small>
            <?php if ($t['nb_non_lus'] > 0): ?>
              <span class="badge-unread"><?= (int)$t['nb_non_lus'] ?></span>
            <?php endif; ?>
          </div>
        </a>
      <?php endforeach; endif; ?>

    </div>
  </div>

  <!-- ── PANNEAU DROIT : messages ────────────────────────────── -->
  <div class="chat-panel">

    <?php if (empty($threads) || $selAnnonce === 0): ?>
      <div class="d-flex flex-column align-items-center justify-content-center h-100 text-muted">
        <i class="bi bi-chat-dots" style="font-size:3rem;"></i>
        <p class="mt-3 mb-0">Sélectionnez une conversation.</p>
      </div>

    <?php else: ?>

      <!-- En-tête du fil -->
      <div class="chat-header">
        <?php if (!empty($annonceActive['image'])): ?>
          <img src="<?= h(image_url($annonceActive['image'])) ?>"
               style="width:44px;height:44px;border-radius:var(--radius-sm);object-fit:cover;flex-shrink:0;" alt="">
        <?php else: ?>
          <div style="width:44px;height:44px;border-radius:var(--radius-sm);background:var(--color-neutral-200);
                      display:flex;align-items:center;justify-content:center;flex-shrink:0;">
            <i class="bi bi-image text-muted"></i>
          </div>
        <?php endif; ?>

        <div class="chat-annonce-info flex-grow-1 min-w-0">
          <div class="annonce-title-small text-truncate"><?= h($annonceActive['titre'] ?? '') ?></div>
          <div class="annonce-price-small"><?= h(format_price($annonceActive['prix'] ?? 0)) ?></div>
        </div>

        <a href="detail-annonce.php?id=<?= (int)$selAnnonce ?>"
           class="btn btn-outline-secondary btn-sm rounded-pill d-none d-md-inline-flex">
          <i class="bi bi-box-arrow-up-right me-1"></i>Voir l'annonce
        </a>

        <?php if ($activeThread): ?>
          <div class="d-flex align-items-center gap-2 flex-shrink-0">
            <div class="conv-avatar" style="width:34px;height:34px;font-size:.82rem;">
              <?= h(strtoupper(substr($activeThread['other_pseudo'], 0, 1))) ?>
            </div>
            <span class="fw-bold d-none d-sm-inline" style="font-size:.86rem;">
              <?= h($activeThread['other_pseudo']) ?>
            </span>
          </div>
        <?php endif; ?>
      </div>

      <!-- Flash -->
      <?php if ($flashSuccess): ?>
        <div class="alert alert-success alert-dismissible mx-3 mt-2 py-2 mb-0">
          <?= h($flashSuccess) ?>
          <button type="button" class="btn-close btn-sm" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>
      <?php if ($flashError): ?>
        <div class="alert alert-danger alert-dismissible mx-3 mt-2 py-2 mb-0">
          <?= h($flashError) ?>
          <button type="button" class="btn-close btn-sm" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>

      <!-- Zone messages -->
      <div class="chat-messages" id="chatMessages">
        <?php if (empty($messages)): ?>
          <div class="text-center text-muted py-5" style="font-size:.9rem;">
            Aucun message — écrivez le premier !
          </div>
        <?php else:
          $prevDate = null;
          foreach ($messages as $msg):
            $isSent   = (int)$msg['sender_id'] === $userId;
            $dir      = $isSent ? 'sent' : 'received';
            $init     = strtoupper(substr($msg['from_pseudo'], 0, 1));
            $msgDate  = date('Y-m-d', strtotime($msg['created_at']));

            // Séparateur de date
            if ($msgDate !== $prevDate):
              $prevDate = $msgDate;
              $today    = date('Y-m-d');
              $yest     = date('Y-m-d', strtotime('-1 day'));
              $dl = $msgDate === $today ? "Aujourd'hui"
                  : ($msgDate === $yest ? 'Hier' : date('d/m/Y', strtotime($msg['created_at'])));
        ?>
              <div class="text-center my-3">
                <span class="badge bg-light text-muted rounded-pill px-3" style="font-size:.72rem;">
                  <?= h($dl) ?>
                </span>
              </div>
          <?php endif; ?>

            <div class="bubble-wrapper <?= $dir ?>">
              <?php if (!$isSent): ?>
                <div class="bubble-avatar"><?= h($init) ?></div>
              <?php endif; ?>
              <div>
                <div class="bubble-time"><?= date('H:i', strtotime($msg['created_at'])) ?></div>
                <div class="bubble"><?= nl2br(h($msg['contenu'])) ?></div>
              </div>
            </div>

          <?php endforeach; endif; ?>
      </div>

      <!-- Formulaire envoi -->
      <form action="envoyer-message.php" method="POST" class="chat-input-bar">
        <input type="hidden" name="annonce_id"  value="<?= (int)$selAnnonce ?>">
        <input type="hidden" name="to_user_id"  value="<?= (int)$selUser ?>">
        <input type="hidden" name="csrf_token"  value="<?= h(csrf_token()) ?>">
        <input type="hidden" name="redirect_to"
          value="messagerie.php?annonce_id=<?= (int)$selAnnonce ?>&user_id=<?= (int)$selUser ?>">
        <textarea class="form-control" id="msgInput" name="contenu"
                  rows="1" placeholder="Votre message…" maxlength="1000" required></textarea>
        <button class="btn-send" type="submit" aria-label="Envoyer">
          <i class="bi bi-send-fill"></i>
        </button>
      </form>

    <?php endif; ?>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  const chat = document.getElementById('chatMessages');
  if (chat) chat.scrollTop = chat.scrollHeight;

  const ta = document.getElementById('msgInput');
  if (ta) {
    ta.addEventListener('input', function() {
      this.style.height = 'auto';
      this.style.height = Math.min(this.scrollHeight, 120) + 'px';
    });
    ta.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        if (this.value.trim()) this.closest('form').submit();
      }
    });
  }
</script>
</body>
</html>
