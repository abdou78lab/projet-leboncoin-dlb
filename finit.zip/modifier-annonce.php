<?php
// ================================================================
// modifier-annonce.php
// CORRECTIFS : états alignés avec la BDD (neuf/bon/correct),
// render_navbar() au lieu de l'ancienne include, image_url()
// ================================================================
require_once __DIR__ . '/includes/bootstrap.php';
require_login();

$userId    = (int)$_SESSION['user_id'];
$annonceId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($annonceId <= 0) {
    set_flash('flash_error', 'Annonce invalide.');
    redirect('mes-annonces.php');
}

$stmt = $pdo->prepare('SELECT * FROM annonces WHERE id = ? AND user_id = ? LIMIT 1');
$stmt->execute([$annonceId, $userId]);
$annonce = $stmt->fetch();

if (!$annonce && !is_admin()) {
    set_flash('flash_error', 'Annonce introuvable ou accès interdit.');
    redirect('mes-annonces.php');
}
// Admin peut modifier n'importe quelle annonce
if (!$annonce) {
    $stmt = $pdo->prepare('SELECT * FROM annonces WHERE id = ? LIMIT 1');
    $stmt->execute([$annonceId]);
    $annonce = $stmt->fetch();
    if (!$annonce) {
        set_flash('flash_error', 'Annonce introuvable.');
        redirect('index.php');
    }
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_fail('modifier-annonce.php?id=' . $annonceId);

    $titre       = trim((string)($_POST['titre']       ?? ''));
    $prix        = trim((string)($_POST['prix']        ?? ''));
    $etat        = trim((string)($_POST['etat']        ?? ''));
    $description = trim((string)($_POST['description'] ?? ''));

    // Validations
    if (strlen($titre) < 3)                                  $errors[] = 'Le titre doit contenir au moins 3 caractères.';
    if (!is_numeric($prix) || (float)$prix < 0)              $errors[] = 'Le prix est invalide.';
    if (!in_array($etat, ['neuf', 'bon', 'correct'], true))  $errors[] = 'État invalide.';
    if (strlen($description) < 10)                           $errors[] = 'La description est trop courte (min 10 caractères).';

    if (!$errors) {
        try {
            // Gestion image
            $supprimerImage = isset($_POST['supprimer_image']);
            $image = $annonce['image'];

            if ($supprimerImage) {
                delete_image_file($image);
                $image = null;
            }

            if (!empty($_FILES['image']['name'])) {
                $image = handle_uploaded_image($_FILES['image'], $supprimerImage ? null : $image);
            }

            $stmt = $pdo->prepare(
                'UPDATE annonces SET titre = ?, prix = ?, etat = ?, description = ?, image = ? WHERE id = ?'
            );
            $stmt->execute([$titre, (float)$prix, $etat, $description, $image, $annonceId]);

            set_flash('flash_success', 'Annonce modifiée avec succès.');
            redirect('detail-annonce.php?id=' . $annonceId);
        } catch (Throwable $e) {
            $errors[] = $e->getMessage();
        }
    }

    // Repopuler le formulaire si erreurs
    $annonce['titre']       = $titre;
    $annonce['prix']        = $prix;
    $annonce['etat']        = $etat;
    $annonce['description'] = $description;
}

$flashError = flash('flash_error');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Modifier l'annonce – DansLeBueno</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@700;800;900&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="style.css">
</head>
<body>
<?php render_navbar(); ?>

<section class="page-hero">
  <div class="container-xl">
    <nav aria-label="breadcrumb" class="mb-1">
      <ol class="breadcrumb mb-0" style="font-size:.82rem;">
        <li class="breadcrumb-item"><a href="index.php">Accueil</a></li>
        <li class="breadcrumb-item"><a href="mes-annonces.php">Mes annonces</a></li>
        <li class="breadcrumb-item active">Modifier</li>
      </ol>
    </nav>
    <h1 class="mb-0">Modifier mon annonce</h1>
  </div>
</section>

<div class="container-xl pb-5">

  <?php if ($errors): ?>
    <div class="alert alert-danger">
      <ul class="mb-0"><?php foreach ($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul>
    </div>
  <?php endif; ?>
  <?php if ($flashError): ?>
    <div class="alert alert-danger"><?= h($flashError) ?></div>
  <?php endif; ?>

  <form method="POST" enctype="multipart/form-data"
        action="modifier-annonce.php?id=<?= (int)$annonceId ?>"
        class="row g-4">
    <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">

    <!-- Colonne principale -->
    <div class="col-12 col-lg-8">
      <div class="bg-white rounded-4 shadow-sm p-4 mb-4">
        <h2 class="section-title mb-4">Informations</h2>

        <div class="mb-3">
          <label class="form-label fw-semibold">Titre <span class="text-danger">*</span></label>
          <input type="text" name="titre" class="form-control" maxlength="120" required
                 value="<?= h((string)$annonce['titre']) ?>">
        </div>

        <div class="row g-3">
          <div class="col-md-5">
            <label class="form-label fw-semibold">Prix (€) <span class="text-danger">*</span></label>
            <input type="number" name="prix" class="form-control" min="0" step="1" required
                   value="<?= h((string)$annonce['prix']) ?>">
          </div>
          <div class="col-md-7">
            <label class="form-label fw-semibold">État <span class="text-danger">*</span></label>
            <div class="d-flex gap-2 flex-wrap mt-1">
              <?php foreach (['neuf' => 'Neuf', 'bon' => 'Bon état', 'correct' => 'État correct'] as $val => $lbl): ?>
                <div>
                  <input type="radio" class="btn-check" name="etat"
                         id="etat-<?= $val ?>" value="<?= $val ?>"
                         <?= ($annonce['etat'] === $val) ? 'checked' : '' ?> required>
                  <label class="btn btn-outline-secondary rounded-pill" for="etat-<?= $val ?>">
                    <?= $lbl ?>
                  </label>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>
      </div>

      <div class="bg-white rounded-4 shadow-sm p-4">
        <h2 class="section-title mb-3">Description <span class="text-danger">*</span></h2>
        <textarea name="description" class="form-control" rows="8" required
                  style="resize:vertical;"><?= h((string)$annonce['description']) ?></textarea>
      </div>
    </div>

    <!-- Colonne photo + actions -->
    <div class="col-12 col-lg-4">
      <div class="bg-white rounded-4 shadow-sm p-4">
        <h2 class="section-title mb-3">Photo</h2>

        <?php if (!empty($annonce['image'])): ?>
          <img src="<?= h(image_url($annonce['image'])) ?>"
               class="img-fluid rounded-3 mb-3 w-100"
               style="max-height:200px;object-fit:cover;"
               alt="Image actuelle">
          <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" name="supprimer_image" id="suppImg">
            <label class="form-check-label text-muted" for="suppImg" style="font-size:.85rem;">
              Supprimer l'image actuelle
            </label>
          </div>
        <?php endif; ?>

        <input type="file" name="image" class="form-control mb-1" accept="image/*">
        <div class="form-text">JPG, PNG, WEBP, GIF — 5 Mo max</div>

        <div class="d-grid gap-2 mt-4">
          <button type="submit" class="btn btn-primary-orange">
            <i class="bi bi-floppy me-1"></i>Enregistrer les modifications
          </button>
          <a href="detail-annonce.php?id=<?= (int)$annonceId ?>"
             class="btn btn-outline-secondary">Annuler</a>
        </div>
      </div>
    </div>
  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
