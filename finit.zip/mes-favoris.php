<?php
// =============================================================
// mes-favoris.php
// =============================================================
require_once __DIR__ . '/includes/bootstrap.php';
require_login();

$userId = (int)$_SESSION['user_id'];

$stmt = $pdo->prepare("
    SELECT
        a.id,
        a.titre,
        a.prix,
        a.etat,
        a.description,
        a.image,
        a.created_at,
        u.pseudo
    FROM favoris f
    INNER JOIN annonces a ON a.id  = f.annonce_id
    INNER JOIN users    u ON u.id  = a.user_id
    WHERE f.user_id = ?
    ORDER BY f.created_at DESC
");
$stmt->execute([$userId]);
$favoris = $stmt->fetchAll();

$flashSuccess = flash('flash_success');
$flashError   = flash('flash_error');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Mes favoris – DansLeBueno</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@700;800;900&family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="style.css" />
</head>
<body>
<?php render_navbar(); ?>

<section class="page-hero">
  <div class="container-xl">
    <nav aria-label="breadcrumb" class="mb-1">
      <ol class="breadcrumb mb-0" style="font-size:.82rem;">
        <li class="breadcrumb-item"><a href="index.php">Accueil</a></li>
        <li class="breadcrumb-item active">Mes favoris</li>
      </ol>
    </nav>
    <h1 class="mb-0">Mes favoris</h1>
  </div>
</section>

<div class="container-xl pb-5">

  <?php if ($flashSuccess): ?>
    <div class="alert alert-success"><?= h($flashSuccess) ?></div>
  <?php endif; ?>
  <?php if ($flashError): ?>
    <div class="alert alert-danger"><?= h($flashError) ?></div>
  <?php endif; ?>

  <?php if (empty($favoris)): ?>
    <div class="empty-state">
      <i class="bi bi-heart"></i>
      <h5 class="mt-2">Aucun favori pour l'instant</h5>
      <p>Ajoutez des annonces à vos favoris pour les retrouver ici.</p>
      <a href="index.php" class="btn btn-primary-orange mt-2 rounded-pill px-4">
        Parcourir les annonces
      </a>
    </div>

  <?php else: ?>
    <div class="row row-cols-1 row-cols-sm-2 row-cols-xl-3 g-3">
      <?php foreach ($favoris as $a): ?>
        <div class="col">
          <div class="annonce-card h-100">
            <a href="detail-annonce.php?id=<?= (int)$a['id'] ?>">
              <?php if (!empty($a['image'])): ?>
                <img
                  src="<?= h(image_url($a['image'])) ?>"
                  alt="<?= h($a['titre']) ?>"
                  class="card-img-top"
                />
              <?php else: ?>
                <div class="img-placeholder">
                  <i class="bi bi-image"></i>
                </div>
              <?php endif; ?>
            </a>

            <div class="card-body d-flex flex-column gap-2">
              <a href="detail-annonce.php?id=<?= (int)$a['id'] ?>"
                class="card-title text-decoration-none text-dark">
                <?= h($a['titre']) ?>
              </a>

              <div class="d-flex align-items-center justify-content-between">
                <span class="annonce-price"><?= h(format_price($a['prix'])) ?></span>
                <span class="badge-etat <?= h($a['etat']) ?>"><?= h(state_label($a['etat'])) ?></span>
              </div>

              <div class="text-muted" style="font-size:.8rem;">
                Vendeur : <?= h($a['pseudo']) ?>
              </div>

              <div class="d-flex align-items-center justify-content-between mt-auto pt-2"
                style="border-top:1px solid var(--color-neutral-100);">
                <a href="detail-annonce.php?id=<?= (int)$a['id'] ?>"
                  class="btn btn-outline-secondary btn-sm rounded-pill">
                  <i class="bi bi-eye me-1"></i>Voir
                </a>
                <!-- Bouton retirer des favoris -->
                <form action="toggle-favori.php" method="POST">
                  <input type="hidden" name="annonce_id"  value="<?= (int)$a['id'] ?>">
                  <input type="hidden" name="csrf_token"  value="<?= h(csrf_token()) ?>">
                  <input type="hidden" name="redirect_to" value="mes-favoris.php">
                  <button type="submit" class="btn-favori active" title="Retirer des favoris">
                    <i class="bi bi-heart-fill"></i>
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

</div>

<footer class="site-footer">
  <div class="container-xl">
    <div class="footer-divider mt-0"></div>
    <p class="text-center mb-0" style="font-size:.8rem;">&copy; <?= date('Y') ?> DansLeBueno – Projet étudiant.</p>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
